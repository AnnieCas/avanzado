//'use strict';

//var b;
//b=10;
//console.log(b)
